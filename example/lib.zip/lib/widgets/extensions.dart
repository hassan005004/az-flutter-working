import 'package:flutter/material.dart';

import 'center.dart';
import 'card.dart';
import 'column.dart';
import 'container.dart';
import 'gesture_detector.dart';
import 'icon.dart';
import 'image.dart';
import 'list_tile.dart';
import 'positioned.dart';
import 'radio_list_tile.dart';
import 'row.dart';
import 'text.dart';
import 'text_form_filed.dart';
import 'wrap.dart';

extension ExtCard on Card {
  AzCard azCard() => AzCard(child);
}

extension ExtCenter on AzCenter {
  AzCard azCenter() => AzCenter(child);
}

extension ExtColumn on AzColumn {
  AzColumn azColumn() => AzColumn(children);
}

extension ExtAzContainer on Container {
  AzContainer azContainer() => AzContainer(widget: this);
}

extension ExtGestureDetector on GestureDetector {
  GestureDetector azGestureDetector() => AzGestureDetector(child);
}

extension ExtIcon on Icon {
  AzIcon azIcon() => AzIcon(icon);
}

extension ExtAssetImage on AssetImage {
  AzImage azAssetImage() => AzImage(assetName);
}
extension ExtINetworkImage on NetworkImage {
  AzImage azNetworkImage() => AzImage(assetName);
}


extension ExtListTile on ListTile {
  AzListTile azListTile() => AzListTile();
}

extension ExtPositioned on Positioned {
  AzPositioned azPositioned() => AzPositioned();
}

extension AzRadioBuilder on RadioListTile {
  AzRadioListTile azRadioListTile() => AzRadioListTile();
}

extension ExtRow on AzRow {
  AzRow azRow() => AzRow(children);
}

extension ExtStack on Stack {
  AzStack azStack() => AzStack(children);
}

extension ExtText on Text {
  AzText azText() => AzText(data ?? "");
}

extension ExtTextFormFiled on TextFormField {
  AzTextFormField azTextFormField() => AzTextFormField();
}

extension ExtWrap on Wrap {
  AzWrap azWrap() => AzWrap(children);
}
