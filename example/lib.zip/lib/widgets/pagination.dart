//
//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
//
// import 'package:az_ui/helper/config.dart';
//
// class AzPageingation extends StatelessWidget{
//   BuildContext context;
//   void Function()? onPressed;
//   void Function(String)? onChanged;
//
//
//   AzPageingation(this.context, {this.onPressed, this.onChanged});
//
//   @override
//   Widget build(BuildContext context) {
//     return InkWell(
//         onTap: onPressed,
//         child: Center(
//           child: Center(
//             child: Text("1",
//               textAlign: TextAlign.center,
//             ),
//           ),
//         )
//     );
//   }
// }
