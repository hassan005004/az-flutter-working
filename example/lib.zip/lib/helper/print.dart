// class Print {
//   static p1(dynamic s){
//     print(s.toString());
//   }
//
//   static override(dynamic s){
//     print(s.toString());
//   }
//
// }
//
